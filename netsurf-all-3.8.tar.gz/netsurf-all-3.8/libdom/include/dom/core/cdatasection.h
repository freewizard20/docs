/*
 * This file is part of libdom.
 * Licensed under the MIT License,
 *                http://www.opensource.org/licenses/mit-license.php
 */

#ifndef dom_core_cdatasection_h_
#define dom_core_cdatasection_h_

typedef struct dom_cdata_section dom_cdata_section;

#endif
